
package Home_Page;

public class Welcome {

	public static void main(String[] args) {
		String stin = "this is the most common way of creating string";
		String stin1 = stin.replace("string","STRING");
		System.out.println("Original sentence: "+stin);
		System.out.println("Replace sentence: "+stin1);

	}

}
