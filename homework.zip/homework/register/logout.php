<?php

// get the from  folder and file register.php
session_start();
session_destroy();
header('location: ../control.php');